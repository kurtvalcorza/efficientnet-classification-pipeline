"""Review probes for tutorials/efficientnet_classification_colab.ipynb (row 23, review of 2026-10-02 batch).

CPU only (CUDA_VISIBLE_DEVICES=-1). Runs the notebook's own code cells in one namespace, with the install
cell's executor hook DIMER_NOTEBOOK_CI_PREINSTALLED=1 (nothing is installed), from an empty working
directory and an empty HF_HOME.

  python run_probes.py static   NOTEBOOK            -> P0 static checks
  python run_probes.py default  NOTEBOOK            -> P1 default Run all, P2 duplicate leakage, P3 freeze rerun
  python run_probes.py byod     NOTEBOOK            -> P4 BYOD positive + negative inputs

Results are merged into results.json next to this script, one key per probe, written as soon as each ends.
"""
from __future__ import annotations

import contextlib
import hashlib
import io
import json
import os
import re
import sys
import time
import traceback
from pathlib import Path

os.environ.setdefault("CUDA_VISIBLE_DEVICES", "-1")
os.environ["DIMER_NOTEBOOK_CI_PREINSTALLED"] = "1"
HERE = Path(__file__).resolve().parent
RESULTS = HERE / "results.json"


def save(key, value):
    data = json.loads(RESULTS.read_text(encoding="utf-8")) if RESULTS.exists() else {}
    data[key] = value
    RESULTS.write_text(json.dumps(data, indent=2, default=str), encoding="utf-8")


def cells(nb_path):
    nb = json.loads(Path(nb_path).read_text(encoding="utf-8"))
    return nb, [(i, "".join(c["source"])) for i, c in enumerate(nb["cells"]) if c["cell_type"] == "code"]


def run_cell(ns, idx, src, log):
    buf = io.StringIO()
    t0 = time.time()
    ok, err = True, None
    with contextlib.redirect_stdout(buf):
        try:
            exec(compile(src, f"<cell {idx}>", "exec"), ns)
        except BaseException as exc:  # noqa: BLE001
            ok, err = False, f"{type(exc).__name__}: {exc}"
            buf.write(traceback.format_exc(limit=2))
    out = buf.getvalue()
    log.append({"cell": idx, "ok": ok, "seconds": round(time.time() - t0, 1), "error": err, "stdout_tail": out[-1500:]})
    return ok


def static(nb_path):
    nb, code = cells(nb_path)
    md = "\n".join("".join(c["source"]) for c in nb["cells"] if c["cell_type"] == "markdown")
    allsrc = "\n".join(s for _, s in code)
    markers = {k: bool(re.search(p, md, re.I)) for k, p in {
        "how_to_use": r"how to use this notebook", "roadmap": r"roadmap", "glossary": r"glossary",
        "audience": r"intended (learner|audience)|this notebook is for", "predict_prompt": r"\bpredict\b.*before|before you run",
        "checkpoint": r"check your (reasoning|understanding)|checkpoint", "troubleshooting": r"troubleshoot",
        "conclusion_template": r"conclusion template|write your conclusion|in your own words",
        "infrastructure_label": r"infrastructure", "what_to_look_for": r"what to look for"}.items()}
    save("P0_static", {
        "code_cells": len(code), "markdown_cells": sum(c["cell_type"] == "markdown" for c in nb["cells"]),
        "pip_install_in_kernel": "'pip', 'install'" in allsrc, "uses_uv": "uv venv" in allsrc or "uv pip" in allsrc,
        "restart_instruction_present": "Restart the runtime" in allsrc,
        "cellView_form_cells": [i for i, c in enumerate(nb["cells"]) if c.get("metadata", {}).get("cellView") == "form"],
        "guided_markers": markers,
        "what_to_look_for_count": len(re.findall(r"what to look for", md, re.I)),
        "claims_independent_thumbnails": "independent thumbnails" in md,
        "mentions_darkened": "darkened" in md.lower(),
        "rerun_scope_stated": bool(re.search(r"re-?run (cells|from)", md, re.I)),
        "finetune_returns_elapsed_time": "elapsed" in allsrc or "wall" in allsrc.split("def finetune")[1][:4000],
        "embedded_line_counts": {i: s.count("\n") + 1 for i, s in code if s.count("\n") > 200},
        "metadata_spec": nb["metadata"].get("dimer", {}).get("notebook_spec"),
    })


def pixel(img):
    return hashlib.sha256(img.convert("RGB").tobytes() + repr(img.size).encode()).hexdigest()


def counterpart(rid):
    # 'CIFAR-10-subset/original_images/frog/0001.png' <-> '.../darkened_images/frog/0001.png'
    return rid.replace("original_images", "@@").replace("darkened_images", "original_images").replace("@@", "darkened_images")


def default(nb_path):
    nb, code = cells(nb_path)
    log, ns = [], {"__name__": "__main__"}
    t0 = time.time()
    for idx, src in code:
        if not run_cell(ns, idx, src, log):
            break
    save("P1_default", {"cells_run": len(log), "cells_ok": sum(e["ok"] for e in log), "code_cells": len(code),
                        "wall_s": round(time.time() - t0, 1), "log": log,
                        "comparison": {k: {"accuracy": v["accuracy"], "balanced_accuracy": v["balanced_accuracy"]}
                                       for k, v in ns.get("comparison", {}).items()},
                        "unseen": {k: ns["unseen_metrics"][k] for k in ("accuracy", "balanced_accuracy", "n")} if "unseen_metrics" in ns else None,
                        "epoch_losses": ns.get("run", {}).get("epoch_losses"),
                        "dataset_manifest": ns.get("dataset_manifest"), "reload_check": ns.get("reload_check"),
                        "adapted_degenerate": ns.get("adapted_degenerate"), "outputs": sorted(os.listdir("outputs")) if os.path.isdir("outputs") else []})
    if "adapter" not in ns or "held_out" not in ns:
        return
    # P2 — duplicate leakage across the split
    tr, ho, un = ns["train_records"], ns["held_out"], ns["unseen"]
    folders = sorted({r["id"].split("/")[-3] if r["id"].count("/") >= 2 else "?" for r in ns["records"]})
    train_pix = {pixel(r["image"]) for r in tr}
    train_ids = {r["id"] for r in tr}

    def leak(part):
        exact = [r for r in part if pixel(r["image"]) in train_pix]
        cp = [r for r in part if counterpart(r["id"]) in train_ids]
        return exact, cp

    p2 = {"top_folders": folders}
    pipe, adapter = ns["pipe"], ns["adapter"]
    groups, maj = ns["IMAGENET_GROUPS"], ns["TRAIN_MAJORITY"]
    for name, part in (("held_out", ho), ("unseen", un)):
        exact, cp = leak(part)
        clean = [r for r in part if pixel(r["image"]) not in train_pix]
        entry = {"n": len(part), "exact_pixel_copy_in_train": len(exact), "same_numbered_counterpart_in_train": len(cp),
                 "clean_n": len(clean), "clean_per_class": {c: sum(r["label"] == c for r in clean) for c in ns["SAMPLE_CLASSES"]}}
        if clean and len({r["label"] for r in clean}) == 2:
            ft = adapter.evaluate(clean, majority=maj)
            zs = pipe.zero_shot_evaluate(clean, groups, majority=maj)
            entry["finetuned_on_clean"] = {"accuracy": ft["accuracy"], "balanced_accuracy": ft["balanced_accuracy"]}
            entry["zero_shot_on_clean"] = {"accuracy": zs["accuracy"], "balanced_accuracy": zs["balanced_accuracy"]}
        if exact:
            ft = adapter.evaluate(exact, majority=maj) if len({r["label"] for r in exact}) == 2 else None
            entry["finetuned_on_leaked"] = ft and {"accuracy": ft["accuracy"], "n": len(exact)}
        p2[name] = entry
    # are 'darkened' images pixel-identical to their originals?
    by_id = {r["id"]: r for r in ns["records"]}
    pairs = [(i, counterpart(i)) for i in by_id if "original_images" in i and counterpart(i) in by_id]
    p2["original_darkened_pairs_in_records"] = len(pairs)
    p2["pairs_pixel_identical"] = sum(pixel(by_id[a]["image"]) == pixel(by_id[b]["image"]) for a, b in pairs)
    save("P2_duplicate_leakage", p2)

    # P3 — active learning as documented: "Set FREEZE_BACKBONE = True and compare"; the field lives in cell 19,
    # no rerun scope is given, so rerun cell 19 and the cells after it (21, 23, 25) as a learner would.
    import torch
    base = ns["EfficientNetPipeline"].from_pretrained(weights_dir=ns["WEIGHTS_DIR"], class_names=ns["SAMPLE_CLASSES"], seed=ns["SEED"])
    name0 = next(n for n, _ in base.model.named_parameters() if n.startswith("conv_stem"))
    before = dict(adapter.model.named_parameters())[name0].detach().clone()
    log3 = []
    src = dict(code)
    src19 = re.sub(r"FREEZE_BACKBONE = False", "FREEZE_BACKBONE = True", src[19])
    t0 = time.time()
    oks = [run_cell(ns, 19, src19, log3)]
    after = dict(ns["adapter"].model.named_parameters())[name0].detach()
    for i in (21, 23, 25):
        oks.append(run_cell(ns, i, src[i], log3))
    save("P3_freeze_rerun_cell19_only", {
        "procedure": "after P1, set FREEZE_BACKBONE=True in cell 19, rerun cells 19, 21, 23, 25",
        "wall_s": round(time.time() - t0, 1), "log": log3,
        "trainable_parameters": ns["run"]["trainable_parameters"], "total_parameters": ns["run"]["total_parameters"],
        "stem_weight_equals_imagenet_base": bool(torch.equal(before.cpu(), dict(base.model.named_parameters())[name0].detach().cpu())),
        "stem_weight_unchanged_by_rerun": bool(torch.equal(before.cpu(), after.cpu())),
        "comparison_after_rerun": {k: v["balanced_accuracy"] for k, v in ns.get("comparison", {}).items()},
        "cell25_ok": oks[-1],
    })


def byod(nb_path):
    from PIL import Image
    nb, code = cells(nb_path)
    src = dict(code)
    log, ns = [], {"__name__": "__main__"}
    for idx in (3, 5, 7, 9, 11, 13):  # setup the namespace the BYOD cell expects (install skipped)
        if not run_cell(ns, idx, src[idx], log):
            save("P4_byod", {"setup_failed": log})
            return
    # cell 19's three form fields (BATCH_SIZE, LEARNING_RATE, FREEZE_BACKBONE) are read by the BYOD cell; in
    # Run all they are defined before it. Define them at their defaults without running the sample fine-tune.
    exec(chr(10).join(l for l in src[19].splitlines() if "# @param" in l), ns)
    records = ns["records"]
    work = Path("byod_inputs")
    # positive: a small class-folder directory, 6 images per class from the sample
    pos = work / "small"
    for label in ("frog", "truck"):
        (pos / label).mkdir(parents=True, exist_ok=True)
        for k, r in enumerate([r for r in records if r["label"] == label][:6]):
            r["image"].save(pos / label / f"{k}.png")
    # negatives
    one = work / "one_per_class"
    for label in ("a", "b"):
        (one / label).mkdir(parents=True, exist_ok=True)
    records[0]["image"].save(one / "a" / "0.png"); records[1]["image"].save(one / "a" / "1.png"); records[-1]["image"].save(one / "b" / "0.png")
    bad = work / "not_image"; (bad / "a").mkdir(parents=True, exist_ok=True); (bad / "b").mkdir(parents=True, exist_ok=True)
    for c in "ab":
        records[0]["image"].save(bad / c / "0.png"); records[1]["image"].save(bad / c / "1.png")
    (bad / "b" / "2.png").write_text("this is not an image", encoding="utf-8")
    txt = work / "notes.png"; txt.write_text("not an image", encoding="utf-8")
    img = work / "frog.png"; records[0]["image"].resize((96, 96)).save(img)
    cases = [
        ("dataset_positive_6_per_class", {"USE_BYOD_DATASET": "True", "BYOD_DATASET_PATH": f'"{pos.as_posix()}"'}),
        ("dataset_one_image_class", {"USE_BYOD_DATASET": "True", "BYOD_DATASET_PATH": f'"{one.as_posix()}"'}),
        ("dataset_non_image_member", {"USE_BYOD_DATASET": "True", "BYOD_DATASET_PATH": f'"{bad.as_posix()}"'}),
        ("dataset_missing_path", {"USE_BYOD_DATASET": "True", "BYOD_DATASET_PATH": '"does/not/exist"'}),
        ("image_positive", {"USE_BYOD_IMAGE": "True", "BYOD_IMAGE_PATH": f'"{img.as_posix()}"'}),
        ("image_text_file", {"USE_BYOD_IMAGE": "True", "BYOD_IMAGE_PATH": f'"{txt.as_posix()}"'}),
    ]
    only = sys.argv[3:] or None
    data = json.loads(RESULTS.read_text(encoding="utf-8")) if RESULTS.exists() else {}
    out = data.get("P4_byod", {})
    for name, fields in cases:
        if only and name not in only:
            continue
        s = src[29]
        for k, v in fields.items():
            s = re.sub(rf"^{k} = .*?(  # @param)", rf"{k} = {v}\1", s, flags=re.M)
        clog = []
        t0 = time.time()
        ok = run_cell(dict(ns), 29, s, clog)
        out[name] = {"ok": ok, "byod_records_after": None, "seconds": round(time.time() - t0, 1), "error": clog[0]["error"], "stdout_tail": clog[0]["stdout_tail"][-1200:]}
        save("P4_byod", out)


if __name__ == "__main__":
    mode, nb_path = sys.argv[1], os.path.abspath(sys.argv[2])
    {"static": static, "default": default, "byod": byod}[mode](nb_path)
